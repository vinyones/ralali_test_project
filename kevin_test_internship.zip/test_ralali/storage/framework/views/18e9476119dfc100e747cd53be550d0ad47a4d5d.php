<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Warehouse</title>
</head>

<style>
    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        width: 200px;
    }
    li a {
        display: block;
        color: black;
        padding: 8px 16px;
        text-decoration: none;
    }
    li a:hover {
        background-color: green;
        color: yellow;
    }
    table {
        width: 100%;
    }
    table th {
        width: 25%;
    }
</style>

<body>
<ul>
    <li><a href="/index/addItem">Add</a></li>
</ul>

<br>

<table border="1">
    <tr>
        <th> Item name</th>
        <th> Item brand</th>
        <th> Quantity</th>
        <th> Price</th>
        <th> Update</th>
        <th> Delete</th>
    </tr>
    <?php $__currentLoopData = $warehouse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <th><?php echo e($item->name); ?></th>
            <th><?php echo e($item->brand); ?></th>
            <th><?php echo e($item->quantity); ?></th>
            <th>Rp <?php echo e($item->price); ?></th>
            <th>
                <a href="/index/edit/<?php echo e($item -> id); ?>">
                    <input type="submit" value="Update">
                </a>
            </th>
            <th>
                <form action="/index/<?php echo e($item -> id); ?>" method="post">
                    <?php echo e(csrf_field()); ?>

                    <?php echo e(method_field('DELETE')); ?>

                    <input type="submit" value="Delete">
                </form>
            </th>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
</body>
</html>
<?php /**PATH C:\Programming Tools\Xampp\htdocs\laravel\test_ralali\resources\views/index.blade.php ENDPATH**/ ?>