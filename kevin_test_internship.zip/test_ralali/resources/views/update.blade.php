<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Warehouse</title>
</head>

<style>
    ul {
        list-style-type: none;
        margin: 0;
        padding: 0;
        width: 200px;
    }
    li a {
        display: block;
        color: black;
        padding: 8px 16px;
        text-decoration: none;
    }
    li a:hover {
        background-color: green;
        color: yellow;
    }
</style>

<body>
<ul>
    <li><a href="/index">Cancel</a></li>
</ul>

<br>

<form action="{{ URL::to('/index' .$warehouse->id) }}" method="post">
    {{ csrf_field() }}
    {{ method_field('PUT') }}

    <h5>Item Name   :</h5> <input type="text" name="name" id="" placeholder="Input name" value="{{ $warehouse->name }}"> <br>
    <h5>Item Brand  :</h5> <input type="text" name="brand" id="" placeholder="Input brand" value="{{ $warehouse->brand }}"> <br>
    <h5>Quantity    :</h5> <input type="text" name="quantity" id="" placeholder="Input quantity" value="{{ $warehouse->quantity }}"> <br>
    <h5>Price       :</h5> <input type="text" name="price" id="" placeholder="Input price" value="{{ $warehouse->price }}"> <br> <br>
    <input type="submit" id="submit" value="Update">
</form>

</body>
</html>
