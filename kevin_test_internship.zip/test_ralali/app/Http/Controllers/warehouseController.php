<?php

namespace App\Http\Controllers;

use App\Warehouse;
use Illuminate\Http\Request;

class warehouseController extends Controller
{
    public function index()
    {
        $warehouse = Warehouse::all();
        return view('index', compact('warehouse'));
    }
    public function create()
    {
        return view('create');
    }
    public function store(Request $request)
    {
        $warehouse = new Warehouse();

        $warehouse->name = $request->name;
        $warehouse->brand = $request->brand;
        $warehouse->quantity = $request->quantity;
        $warehouse->price = $request->price;

        $warehouse->save();

        return redirect('/index');
    }
    public function edit($id)
    {
        $warehouse = Warehouse::find($id);
        return view('update', compact('warehouse'));
    }
    public function update(Request $request, $id)
    {
        $warehouse = Warehouse::find($id);
        $warehouse->name = $request->name;
        $warehouse->brand = $request->brand;
        $warehouse->quantity = $request->quantity;
        $warehouse->price = $request->price;

        $warehouse->save();

        return redirect('/index');
    }
    public function destroy($id)
    {
        $warehouse = Warehouse::find($id);
        $warehouse->delete();

        return redirect('/index');
    }
}
